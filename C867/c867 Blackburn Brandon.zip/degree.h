#pragma once

enum DegreeType { SECURITY, NETWORK, SOFTWARE};